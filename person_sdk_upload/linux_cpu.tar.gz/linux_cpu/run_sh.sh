mkdir ./lib

cd ./src

gcc gemm.c utils.c avgpool_layer.c convolutional_layer.c deconvolutional_layer.c list.c image.c activations.c im2col.c col2im.c blas.c maxpool_layer.c data.c matrix.c network.c parser.c option_list.c activation_layer.c route_layer.c local_layer.c crop_layer.c gru_layer.c dropout_layer.c crnn_layer.c lstm_layer.c rnn_layer.c reorg_layer.c detection_layer.c connected_layer.c softmax_layer.c cost_layer.c shortcut_layer.c batchnorm_layer.c normalization_layer.c box.c layer.c region_layer.c tree.c person_lib_api.c cuda.c -pthread -lm -fPIC -shared -Ofast -o ../lib/libpersonapi.so

cp person_lib_api.h ../lib/
cp ../lib/* ../test_lib

cd ../test_lib

gcc main.cpp -I/usr/local/include -L. -lpersonapi  -L/usr/local/cuda-8.0/lib64 -lcudart -L/usr/local/lib -lopencv_core -lopencv_imgcodecs -lopencv_highgui -lopencv_imgproc -lopencv_videoio -lstdc++ -Ofast -o main

./main ./model/navlab.cfg ./model/navlab_300000.weights ./model/IR13.asf

cd ..
