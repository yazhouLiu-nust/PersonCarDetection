./main ./test_lib/model/navlab.cfg ./test_lib/model/navlab_300000.weights ./test_lib/model/IR13.asf


